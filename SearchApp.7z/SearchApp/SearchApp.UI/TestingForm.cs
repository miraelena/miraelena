using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SearchApp.UI
{
    public partial class TestingForm : Form
    {
        public TestingForm()
        {
            InitializeComponent();
        }


        private void PreviewResults(string sQuery)
        {            
            try
            {               
                int nRows;
                DataSet dsResult;
                DBClass.GetData(sQuery, dataGridView1, out dsResult, out nRows);
                lblCount.Text = nRows.ToString();                
                SetGrid(dataGridView1);   
            }
            catch (Exception e)
            {
               MessageBox.Show("Error: "+e.Message);
            }
       
        }
        private void SearchData()
        {
            string sQuery = "";
            string sFilter = tbSearch.Text;
            lblSearch1.Text = tbSearch.Text;
            /*
            if (rbAll.Checked==false &&  String.IsNullOrWhiteSpace(sFilter))
            {
                MessageBox.Show("Eneter at least 1 character for specific searches.");
                tbSearch.Focus();
                return;
            } */

            if (rbAll.Checked)
            {
               sQuery = "select * from results where text like '%" + sFilter +
              "%' order by text";
            }
            if (rbWeighted.Checked)
            {
                //sQuery = "select * from results where text like '" + sFilter + "%' order by weight desc";
                sQuery = "select * from results where text like '%" + sFilter + "%' order by weight desc";
            }
            else if (rbStartingText.Checked)
            {
                sQuery = "select * from results where text like '" + sFilter + "%'  order by text";
            }
            else if (rbContainingText.Checked)
            {               
                sQuery = "select  * from results where text like '%" + sFilter + "%'  order by text";
            }

            PreviewResults(sQuery);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            tbSearch.Text = "";            
            rbAll.Checked=true;
            EmptyGrid();
        }

        private void EmptyGrid()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            lblCount.Text = "";
        }

        private void rbAll_CheckedChanged(object sender, EventArgs e)
        {            
            
        }

       
        private void SetGrid(DataGridView dgv)
        {
            foreach (DataGridViewColumn col in dgv.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.HeaderCell.Style.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold, GraphicsUnit.Pixel);
            }           

            dgv.Columns["id_result"].HeaderText = "ID";
            
            dgv.Columns["text"].HeaderText = "Result";
            dgv.Columns["text"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgv.Columns["weight"].HeaderText = "Weight";

            if (dgv==dataGridView1)
            {
                dgv.Columns["id_result"].Width = 60;
                dgv.Columns["text"].Width = 300;
                dgv.Columns["weight"].Width = 100;                
            }
            else if (dgv == dataGridView2)
            {
                dgv.Columns["id_result"].Width = 50;
                dgv.Columns["text"].Width = 170;
                dgv.Columns["weight"].Width = 70;

                dgv.Columns["search_criteria"].HeaderText = "Search by";
                dgv.Columns["search_criteria"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv.Columns["search_criteria"].Width = 200;

                dgv.Columns["priority"].HeaderText = "Priority";
                dgv.Columns["priority"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv.Columns["priority"].Width = 80;//60;
                dgv.Columns["priority"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            
        }
    

        private void TestingForm_Shown(object sender, EventArgs e)
        {
            try
            {
                rbAll.Checked = true;
                SearchData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void rbWeighted_Click(object sender, EventArgs e)
        {
            /*if (String.IsNullOrWhiteSpace(tbSearch.Text))
            {
                MessageBox.Show("Eneter at least 1 character for specific searches.");
                tbSearch.Focus();
                rbAll.Checked = true;
                return;
            }*/
            SearchData();
        }

        private void btnDropDownData_Click(object sender, EventArgs e)
        {
            DataTable dtDropDown= DBClass.GenerateDataForDropDown(tbSearch.Text);
            lblSearch2.Text = tbSearch.Text;
            lblCountDD.Text = dtDropDown.Rows.Count.ToString();
            dataGridView2.DataSource = dtDropDown.DefaultView;
            SetGrid(dataGridView2);
        }
               
    }
}
