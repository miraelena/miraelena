﻿using System;
using System.Data.SqlClient;
using System.Xml;
using System.IO;
using System.Windows.Forms;
using System.Data;
using System.Linq;
    

namespace SearchApp.UI
{
    public static class DBClass
    {
        public static SqlConnection connection;      
        static public string stringConnection;

        static public SqlConnection CreateConnection()
        {
            // Create a connection object
            SqlConnection sqlconn = new SqlConnection();           

            XmlDocument xmldoc = new XmlDocument();
            Directory.SetCurrentDirectory(Application.StartupPath);
            System.IO.FileInfo fi = new FileInfo("Connections.xml");
            if (fi.Exists == true)
            {
                xmldoc.Load("Connections.xml");
                XmlNode node = xmldoc.SelectSingleNode("/Connections/Connection1");
                if (node != null)
                {
                    stringConnection = node.InnerText;
                }
                else
                {
                    MessageBox.Show("Error reading XML");
                }
            }
            else
            {
                MessageBox.Show("No Connection File");
            }

            sqlconn.ConnectionString = stringConnection;
            try
            {
                sqlconn.Open();                
            }
            catch (Exception)
            {
                MessageBox.Show("Error: " + stringConnection);
            }
            return sqlconn;
        }

        static public void GetData(string sQuery, out DataSet ds1)
        {
            ds1 = new DataSet();

            SqlConnection scon = CreateConnection(); // CreateConnection();
            if (scon != null && scon.State == ConnectionState.Closed)
                scon.Open();

            try
            {
                SqlDataAdapter dal = new SqlDataAdapter(sQuery, stringConnection);
                dal.Fill(ds1, "tabela");
            }

            catch { scon.Close(); }
            scon.Close();
        }

        static public void GetData(string sQuery, out DataSet ds1, out int numOfRows)
        {
            ds1 = new DataSet();
            numOfRows = 0;

            SqlConnection scon = CreateConnection();
            if (scon != null && scon.State == ConnectionState.Closed)
                scon.Open();

            try
            {
                SqlDataAdapter dal = new SqlDataAdapter(sQuery, stringConnection);
                dal.Fill(ds1, "tabela");
                numOfRows = ds1.Tables[0].Rows.Count;
            }

            catch { scon.Close(); }
            scon.Close();
        }


        static public void GetData(string sQuery, DataGridView dg, out DataSet ds1)
        {
            ds1 = new DataSet();

            try
            {
                GetData(sQuery, out ds1);               
                dg.DataSource = ds1.Tables[0].DefaultView;
            }

            catch
            {
                dg.DataSource = null;
            }
        }

        static public void GetData(string sQuery, DataGridView dg, out DataSet ds1, out int numOfRows)
        {
            ds1 = new DataSet();
            int nRows = 0;
            try
            {
                GetData(sQuery, out ds1, out nRows);       
                dg.DataSource = ds1.Tables[0].DefaultView;               
            }
            catch
            {
                dg.DataSource = null;
            }
            finally
            {
                numOfRows = nRows;
            }
        }

        static public void UpdateResults(string txt, int wei)
        {
            SqlConnection scon = CreateConnection(); 
            if (scon != null && scon.State == ConnectionState.Closed)
                scon.Open();

            try
            {
                String com = "UPDATE results SET weight=" + wei.ToString() + " WHERE text ='" + txt + "'";
                SqlCommand command = new SqlCommand(com, scon);
                int res = command.ExecuteNonQuery();
            }

            catch { scon.Close(); }
            scon.Close();            
        }

        static public void UpdateResults(string txt)
        {
            SqlConnection scon = CreateConnection();
            if (scon != null && scon.State == ConnectionState.Closed)
                scon.Open();

            try
            {
                int wei = ReturnWeight(txt)+1;
                String com = "UPDATE results SET weight=" + wei.ToString() + " WHERE text ='" + txt + "'";
                SqlCommand command = new SqlCommand(com, scon);
                int res = command.ExecuteNonQuery();
            }

            catch { scon.Close(); }
            scon.Close();
        }

        static public int ReturnWeight(string name)
        {
            string sQuery = "select weight from results where text='"+name+"'";
            int numRows;
            int wei = 0;
            GetData(sQuery, out DataSet ds1,out numRows);
            if (numRows>0)
            {
                 wei =Convert.ToInt32(ds1.Tables[0].Rows[0]["weight"].ToString());
            }
            return wei;
        }

        static public DataTable GenerateDataForDropDown(string sFilter)
        {
            //first filter data from database-table, and return records that contain some input text (sfilter)
            string sfilter = sFilter.ToLower();
            DataSet ds1;
            DataTable dtSource = new DataTable();
            string sQuery = "select id_result,text,weight from results " +
                "where text like '%" + sfilter + "%' order by text";
            DBClass.GetData(sQuery, out ds1);
            dtSource = ds1.Tables[0];
            // filtered data is stored in DataTable: dtSource

            //copy dtSource table to working table:dtWorking 
            DataTable dtWorking = dtSource.Clone();
            foreach (DataRow row in dtSource.Rows)
            {
                dtWorking.Rows.Add(row.ItemArray);
            }

            /* newTable will be used to fill and empty data for each of the tasks 
            under a b and c. After completing each task, results from newTable
            will be appended to resultTable */
            DataTable newTable = dtSource.Clone();            
            DataColumn newColumn1 = new System.Data.DataColumn("search_criteria", typeof(System.String));
            newTable.Columns.Add(newColumn1);
            DataColumn newColumn2 = new System.Data.DataColumn("priority", typeof(System.String));
            newTable.Columns.Add(newColumn2);
            DataTable resultTable = newTable.Clone();

            // table A:
            //Top weighted results which start with that string: max 5:            
            //foreach (DataRow row in dtSource.Select("1=1", "weight DESC").Take(5)) //top 5 weight

            //Top weighted results which contains that string: max 5: 
            foreach (DataRow row in dtWorking.Select("1=1", "weight DESC").Where(r => r.ItemArray[1].ToString().ToLower().Contains(sfilter)).Take(5))
            {
                newTable.Rows.Add(row.ItemArray);
            }

            int pri = 0;
            foreach (DataRow row in newTable.Rows)
            {
                row["search_criteria"] = "Weighted";
                row["priority"] = "a" + pri.ToString();                
                pri++;
                resultTable.Rows.Add(row.ItemArray);
            }

            //delete rows from working table, that are already used in result table:           
            foreach (DataRow drrez in resultTable.Rows)
            {
                DataRow[] drr = dtWorking.Select("id_result=" + drrez["id_result"].ToString());
                for (int k = 0; k < drr.Length; k++)
                    drr[k].Delete();
                dtWorking.AcceptChanges();
            }

            //table B:
            newTable.Clear();
            foreach (DataRow row in dtWorking.Select("1=1", "text ASC").Where(r => r.ItemArray[1].ToString().ToLower().StartsWith(sfilter)).Take(5))
            {
                newTable.Rows.Add(row.ItemArray);
            }
            pri = 0;
            foreach (DataRow row in newTable.Rows)
            {
                row["search_criteria"] = "Start match Alphabetical";
                row["priority"] = "b" + pri.ToString();
                pri++;

                resultTable.Rows.Add(row.ItemArray);
            }

            //delete rows from working table, that are already used in result table:          
            foreach (DataRow drrez in resultTable.Rows)
            {
                DataRow[] drr = dtWorking.Select("id_result=" + drrez["id_result"] + " ");
                for (int k = 0; k < drr.Length; k++)
                    drr[k].Delete();
                dtWorking.AcceptChanges();
            }

            //table C:
            newTable.Clear();
            foreach (DataRow row in dtWorking.Select().Where(r => r.ItemArray[1].ToString().ToLower().Contains(sfilter)).Take(20))
            {
                newTable.Rows.Add(row.ItemArray);
            }
            pri = 0;
            foreach (DataRow row in newTable.Rows)
            {
                row["search_criteria"] = "Containing match Alphabetical";
                row["priority"] = "c" + pri.ToString();
                pri++;

                resultTable.Rows.Add(row.ItemArray);
            }
            return resultTable;
        }

    }
}
