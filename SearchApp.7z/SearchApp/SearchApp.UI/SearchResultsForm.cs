using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SearchApp.UI
{
    public partial class SearchResultsForm : Form
    {
        public SearchResultsForm()
        {
            InitializeComponent();
        }

        private DataSet dsResult;
        private DataTable dtResult;
        private int numOfRows;       

        private void FillComboBox()
        {
            try
            {
                string sQuery = "select * from results order by text";
                DBClass.GetData(sQuery, out dsResult, out numOfRows);
                dtResult = dsResult.Tables[0];
            }
            catch (Exception e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            //MessageBox.Show(numOfRows.ToString());
        }

        private void PreviewResults(string sQuery)
        {            
            try
            {               
                int nRows;
                DataSet ds1;

                if (String.IsNullOrEmpty(sQuery))
                {
                    sQuery = "select * from results order by text";
                }
                DBClass.GetData(sQuery, dataGridView1, out ds1, out nRows);
                lblCount.Text = nRows.ToString();                
                SetGrid();   
            }
            catch (Exception e)
            {
               MessageBox.Show("Error: "+e.Message);
            }
       
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {            
            //string sFilter = cbSearch.Text;
            //string sQuery  = "select * from results where text like '" + sFilter +
            // "%' order by text";
            
            PreviewResults("");
        }
       
        private void EmptyGrid()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            lblCount.Text = "";
        }

        private void rbAll_CheckedChanged(object sender, EventArgs e)
        {
            EmptyGrid();
        }

        private void SetGrid()
        {
            foreach (DataGridViewColumn col in dataGridView1.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.HeaderCell.Style.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold, GraphicsUnit.Pixel);
            }

            dataGridView1.Columns["id_result"].Width = 60;
            dataGridView1.Columns["id_result"].HeaderText = "ID";

            dataGridView1.Columns["text"].Width = 330;
            dataGridView1.Columns["text"].HeaderText = "Result";
            dataGridView1.Columns["text"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dataGridView1.Columns["weight"].Width = 80;
            dataGridView1.Columns["weight"].HeaderText = "Weight";
        }

        private DataTable dtDropDown;
        private void cbSearch_KeyUp(object sender, KeyEventArgs e)
        {
            string srch = cbSearch.Text.ToLower();
            if (srch.Length >= 3)
            {
                dtDropDown = DBClass.GenerateDataForDropDown(srch);
                string srch_str = "qwertzuioplkjhgfdsayxcvbnmQWERTZUIOPLKJHGFDSAYXCVBNM";
                if (srch_str.IndexOf(e.KeyCode.ToString()) >= 0)
                {
                    cbSearch.DisplayMember = "text"; 
                    cbSearch.ValueMember = "id_result"; 
                    DataView dvResult = new DataView(dtDropDown);
                    //dvResult.RowFilter = "text LIKE '%" + srch + "%'"; 
                    cbSearch.DataSource = dvResult;          
                    cbSearch.SelectedIndex = -1;                   
                    cbSearch.Text = srch;                    
                    cbSearch.Select(100, 0);
                    cbSearch.DroppedDown = true; 
                }            
            }
        }

        private void SearchResultsForm_Shown(object sender, EventArgs e)
        {
            FillComboBox();           
            PreviewResults("");
        }

        private void cbSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selItem = this.cbSearch.Text;    
            if (!String.IsNullOrWhiteSpace(selItem))
            {
                DBClass.UpdateResults(selItem);
                PreviewResults("");
            }            
        }

        
    }
}
